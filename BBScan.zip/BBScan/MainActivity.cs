﻿using Android.App;
using Android.OS;
using Android.Runtime;
using Android.Widget;
using AndroidX.AppCompat.App;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;

namespace BBScan
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        EditText inputOperador, inputSemana, inputRack, inputCircuito, inputCantidad;
        Spinner spinnerTipoOperacion;
        Button submitButton;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.activity_main);

            // Inicializar los EditText
            inputOperador = FindViewById<EditText>(Resource.Id.inputOperador);
            inputSemana = FindViewById<EditText>(Resource.Id.inputSemana);
            inputRack = FindViewById<EditText>(Resource.Id.inputRack);
            inputCircuito = FindViewById<EditText>(Resource.Id.inputCircuito);
            inputCantidad = FindViewById<EditText>(Resource.Id.inputCantidad);

            // Configurar navegación con Enter
            inputOperador.EditorAction += (sender, e) =>
            {
                if (e.ActionId == Android.Views.InputMethods.ImeAction.Next)
                {
                    inputSemana.RequestFocus();
                    e.Handled = true;
                }
            };

            inputSemana.EditorAction += (sender, e) =>
            {
                if (e.ActionId == Android.Views.InputMethods.ImeAction.Next)
                {
                    inputRack.RequestFocus();
                    e.Handled = true;
                }
            };

            inputRack.EditorAction += (sender, e) =>
            {
                if (e.ActionId == Android.Views.InputMethods.ImeAction.Next)
                {
                    inputCircuito.RequestFocus();
                    e.Handled = true;
                }
            };

            inputCircuito.EditorAction += (sender, e) =>
            {
                if (e.ActionId == Android.Views.InputMethods.ImeAction.Next)
                {
                    inputCantidad.RequestFocus();
                    e.Handled = true;
                }
            };

            inputCantidad.EditorAction += (sender, e) =>
            {
                if (e.ActionId == Android.Views.InputMethods.ImeAction.Done)
                {
                    // Aquí puedes realizar alguna acción si es necesario cuando se presione Enter en el último campo.
                    e.Handled = true;
                }
            };

            // Inicializar el Spinner
            spinnerTipoOperacion = FindViewById<Spinner>(Resource.Id.spinnerTipoOperacion);

            // Crear un adaptador para el Spinner
            var operaciones = new string[] { "Entrada", "Salida" };
            var adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleSpinnerItem, operaciones);
            adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            spinnerTipoOperacion.Adapter = adapter;

            //adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            //spinnerTipoOperacion.Adapter = adapter;

            // Inicializar el botón
            submitButton = FindViewById<Button>(Resource.Id.submitButton);

            // Evento Click para el botón
            submitButton.Click += (sender, e) =>
            {
                // Validar que ningún campo esté vacío
                if (string.IsNullOrWhiteSpace(inputOperador.Text) ||
                    string.IsNullOrWhiteSpace(inputSemana.Text) ||
                    string.IsNullOrWhiteSpace(inputRack.Text) ||
                    string.IsNullOrWhiteSpace(inputCircuito.Text) ||
                    string.IsNullOrWhiteSpace(inputCantidad.Text))
                {
                    Toast.MakeText(this, "Por favor, completa todos los campos.", ToastLength.Short).Show();
                }
                else
                {
                    // Aquí puedes añadir la lógica para procesar los datos si todos los campos están llenos.
                    //Toast.MakeText(this, "Todos los campos están llenos.", ToastLength.Short).Show();
                    // Guardar los datos en la base de datos
                    SaveDataToApi(inputOperador.Text,
                                       inputSemana.Text,
                                       inputRack.Text,
                                       inputCircuito.Text,
                                       inputCantidad.Text,
                                       spinnerTipoOperacion.SelectedItem.ToString());              
                }
            };

            // Configurar el controlador global de excepciones
            AndroidEnvironment.UnhandledExceptionRaiser += (sender, args) =>
            {
                // Registrar el error
                LogUnhandledException(args.Exception);

                // Mostrar un mensaje al usuario
                Toast.MakeText(this, "Ocurrió un error inesperado. La aplicación continuará funcionando.", ToastLength.Long).Show();

                // Evitar que la aplicación se cierre
                args.Handled = true;
            };
        }

        private async void SaveDataToApi(string operador, string semana, string rack, string circuito, string cantidad, string tipoOperacion)
        {
            var data = new
            {
                Operador = operador,
                Semana = semana,
                Rack = rack,
                Circuito = circuito,
                Cantidad = cantidad,
                TipoOperacion = tipoOperacion
            };

            var json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            { 
                using (var client = new HttpClient())
                {
                    var response = await client.PostAsync("http://IPSERVER:5000/api/save_data", content);
                    if (response.IsSuccessStatusCode)
                    {
                        // Datos guardados exitosamente
                        Toast.MakeText(this, "Datos guardados exitosamente.", ToastLength.Short).Show();
                        // Limpiar los campos, excepto Operador y Tipo de Operación
                        inputSemana.Text = "";
                        inputRack.Text = "";
                        inputCircuito.Text = "";
                        inputCantidad.Text = "";
                        inputSemana.RequestFocus();
                    }
                    else
                    {
                        // Manejar errores
                        Toast.MakeText(this, "Error, intente de nuevo", ToastLength.Short).Show();
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar la excepción
                LogUnhandledException(ex);
                Toast.MakeText(this, "Ocurrió un error. Por favor, inténtalo de nuevo. Error: " + ex.ToString(), ToastLength.Long).Show();
            }
        }

        private void LogUnhandledException(Exception exception)
        {
            // Aquí puedes registrar el error en un archivo, base de datos, etc.
            System.Diagnostics.Debug.WriteLine(exception);
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
