﻿from flask import Flask, request, jsonify
import pyodbc

app = Flask(__name__)

@app.route('/api/save_data', methods=['POST'])
def save_data():
    data = request.get_json()
    operador = data.get('Operador')
    semana = data.get('Semana')
    rack = data.get('Rack')
    circuito = data.get('Circuito')
    cantidad = data.get('Cantidad')
    tipo_operacion = data.get('TipoOperacion')

    connection_string = "DRIVER={SQL Server};SERVER=DATABASERSERVER;DATABASE=DBTABLE;UID=USER;PWD=PASSWORD"

    try:
        conn = pyodbc.connect(connection_string)
        cursor = conn.cursor()
        query = """
        INSERT INTO BBSCan (Operador, Semana, Rack, Circuito, Cantidad, TipoOperacion)
        VALUES (?, ?, ?, ?, ?, ?)
        """
        cursor.execute(query, (operador, semana, rack, circuito, cantidad, tipo_operacion))
        conn.commit()
        return jsonify({"message": "Data saved successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    from waitress import serve
    serve(app, host="IPSERVER", port=5000)
